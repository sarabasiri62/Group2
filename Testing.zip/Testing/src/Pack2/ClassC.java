package Pack2;

public class ClassC {
	public ClassC(){
		
	}
	public static double x;
	public static double y;
	public int getC(){
		return 0;
	}

}
