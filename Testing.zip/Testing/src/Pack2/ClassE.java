package Pack2;

public class ClassE {
	public void m2(){
		ClassD.z = 5;
	}
}
