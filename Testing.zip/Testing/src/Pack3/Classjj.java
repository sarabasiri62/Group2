package Pack3;

public class Classjj {
	public static double x;
	public static double y;
	
	public void mj1(){
		
	}
	public void mj2(){
		
	}
	public void mj3(){
	
	}
	public void mj4(){
	
	}
	public void mj5(){
	
	}
	public void mj6(){
	
	}
	public void mj7(){
	
	}
	
	

}
