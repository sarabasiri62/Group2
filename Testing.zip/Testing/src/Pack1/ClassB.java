package Pack1;

public class ClassB {
	private ClassA a;
	private ClassA a2;
	

}
