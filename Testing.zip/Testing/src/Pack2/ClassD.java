package Pack2;

public class ClassD {
	public static double z;
	private void m(){
		int b;
		ClassC c = new ClassC();
		ClassC.x = 0;
		ClassC.y = 1;
		b = c.getC();
	}

}
