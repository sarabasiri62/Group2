package Pack1;

public class ClassF {
	private ClassA af;
	private ClassA af2;
}
