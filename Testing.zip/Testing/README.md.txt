# Testing project 
This project is for testing the *JD project*. Basically, the *JD project* runs as Eclipse Application, and it computes **metrics** for the project that runs in that Eclipse Application, so having a test project with **expected result** helps us to see if the project works well or not.

The "Testing" project contains three packages that covers all the different types of inherited attribute, inherited method, overriding method, calling methods, etc. 

* According to the precise calculation this project should have following metrics:
* AHF = 54.54545454545454 %
* AIF = 15.384615384615385 %
* CF = 7.142857142857142 %
* MHF = 20.0 %
* MIF = 54.54545454545454 %
* PF = 42.857142857142854 %

Whenever the developer makes some changes in the JD project, this Testing project should be run and the result should be the same.
