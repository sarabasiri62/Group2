package Pack1;

public class ClassA {
	
protected void mA1() {
		
	}
	private void mA2() {
		
	}

}
