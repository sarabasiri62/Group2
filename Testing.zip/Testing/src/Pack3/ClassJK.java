package Pack3;

import Pack2.ClassC;

public class ClassJK extends Classjj{
	
	private Classjj a;
	private Classjj a2;
	
	
	
	public ClassJK(){
		Classjj.x = 0;
		Classjj.y = 1;
	}

	public void mj1() {
		
		
	}

	public void mj2() {
		
		
	}

	public void mj3() {
		
		
	}

	

}
